package dev.xkmc.modulargolems.content.entity.humanoid.weapon;

import dev.xkmc.mob_weapon_api.api.goals.IMeleeGoal;
import dev.xkmc.mob_weapon_api.api.goals.IRangedWeaponGoal;
import dev.xkmc.modulargolems.content.entity.humanoid.HumanoidGolemEntity;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.RangedAttackGoal;
import net.minecraft.world.entity.projectile.Projectile;
import net.minecraft.world.item.ItemStack;

public class GolemTridentAttackGoal extends RangedAttackGoal implements IRangedWeaponGoal<HumanoidGolemEntity> {
	private final HumanoidGolemEntity golem;
	private final IMeleeGoal melee;
	private final float radius;

	public GolemTridentAttackGoal(HumanoidGolemEntity pRangedAttackMob, double pSpeedModifier, int pAttackInterval, float pAttackRadius, IMeleeGoal melee) {
		super(pRangedAttackMob, pSpeedModifier, pAttackInterval, pAttackRadius);
		this.golem = pRangedAttackMob;
		this.melee = melee;
		this.radius = pAttackRadius;
	}

	@Override
	public double range(ItemStack stack) {
		return radius;
	}

	public boolean canUse() {
		LivingEntity target = golem.getTarget();
		if (target == null || !super.canUse()) return false;
		if (melee.canReachTarget(target)) return false;
		InteractionHand hand = golem.getWeaponHand();
		return GolemShooterHelper.isValidThrowableWeapon(this.golem, this.golem.getItemInHand(hand), hand);
	}

	public void start() {
		super.start();
		golem.setAggressive(true);
		golem.setInRangeAttack(true);
		golem.startUsingItem(golem.getWeaponHand());
	}

	public void stop() {
		super.stop();
		golem.stopUsingItem();
		golem.setAggressive(false);
		golem.setInRangeAttack(false);
	}

	@Override
	public void performRangedAttack(LivingEntity target, float power, ItemStack stack, InteractionHand hand) {
		var throwable = GolemShooterHelper.throwWeapon(golem, stack, hand);
		if (throwable != null && throwable.isThrowable()) {
			Projectile projectile = throwable.createProjectile(golem.level());
			GolemShooterHelper.shootAimHelper(target, projectile);
			golem.playSound(SoundEvents.TRIDENT_THROW.value(), 1.0F, 1.0F / (golem.getRandom().nextFloat() * 0.4F + 0.8F));
			projectile.getPersistentData().putInt("DespawnFactor", 20);
			golem.level().addFreshEntity(projectile);
			stack.hurtAndBreak(1, golem, EquipmentSlot.MAINHAND);
		}
	}

}