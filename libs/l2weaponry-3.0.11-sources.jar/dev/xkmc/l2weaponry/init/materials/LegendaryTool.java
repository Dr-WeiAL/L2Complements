package dev.xkmc.l2weaponry.init.materials;

import dev.xkmc.l2damagetracker.contents.materials.api.ITool;
import dev.xkmc.l2damagetracker.contents.materials.generic.ExtraToolConfig;
import dev.xkmc.l2serial.util.Wrappers;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Tier;

public record LegendaryTool<T extends Item>(LWToolTypes type, LegendaryToolFactory<T> tool) implements ITool {

	public T parse(LWToolMats mat, Item.Properties p) {
		return Wrappers.cast(mat.type.getToolConfig().sup().get(mat.type, this, p));
	}

	@Override
	public int getDamage(int i) {
		return type.getDamage(i);
	}

	@Override
	public float getAtkSpeed(float v) {
		return type.getAtkSpeed(v);
	}

	@Override
	public Item create(Tier tier, Item.Properties properties, ExtraToolConfig extraToolConfig) {
		return tool.get(tier, properties, extraToolConfig);
	}

}
