package dev.xkmc.l2damagetracker.contents.attack;

import dev.xkmc.l2damagetracker.contents.immunity.ImmunityDataExtra;
import dev.xkmc.l2damagetracker.contents.logging.AttackLogEntry;
import dev.xkmc.l2damagetracker.init.L2DamageTracker;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.neoforged.bus.api.Event;
import net.neoforged.neoforge.common.damagesource.DamageContainer;
import net.neoforged.neoforge.entity.PartEntity;
import net.neoforged.neoforge.event.entity.living.LivingDamageEvent;
import net.neoforged.neoforge.event.entity.living.LivingIncomingDamageEvent;
import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;

@SuppressWarnings("unused")
public class DamageDataExtra implements DamageData.All {

	private DamageSource source;
	private LivingEntity target;
	private LivingEntity attacker;
	private ItemStack weapon = ItemStack.EMPTY;
	private PlayerAttackCache player;
	private DamageContainer cont;

	private final DamageAccumulator offenseModifiers = new DamageAccumulator();
	private final DamageAccumulator defenseModifiers = new DamageAccumulator();

	@Nullable
	private AttackLogEntry log;

	private boolean bypassMagic;
	private float originalDamage;
	private boolean noCancellation;
	private Event logEvent;

	public boolean bypassMagic() {
		return bypassMagic;
	}

	public DamageSource getSource() {
		return source;
	}

	public DamageContainer getContainer() {
		return cont;
	}

	public LivingEntity getTarget() {
		return target;
	}

	@Nullable
	public LivingEntity getAttacker() {
		return attacker;
	}

	public ItemStack getWeapon() {
		return weapon;
	}

	public float getStrength() {
		return player == null ? 1 : player.getStrength();
	}

	public float getDamageOriginal() {
		return originalDamage;
	}

	public float getDamageIncoming() {
		return offenseModifiers.getMaximized();
	}

	public float getDamageFinal() {
		return defenseModifiers.getMaximized();
	}

	public void addHurtModifier(DamageModifier mod) {
		if (log != null) log.recordModifier(mod);
		offenseModifiers.addHurtModifier(mod);
	}

	public void addDealtModifier(DamageModifier mod) {
		if (log != null) log.recordModifier(mod);
		defenseModifiers.addHurtModifier(mod);
	}

	@Override
	public void setNonCancellable() {
		noCancellation = true;
		if (log != null) log.logNoImmunity();
	}

	@Override
	public @Nullable PlayerAttackCache getPlayerData() {
		return player;
	}

	public void init(DamageSource source, float originalDamage) {
		this.source = source;
		this.originalDamage = originalDamage;
		this.bypassMagic = source.is(DamageTypeTags.BYPASSES_INVULNERABILITY) ||
				source.is(DamageTypeTags.BYPASSES_EFFECTS);
		Entity e = source.getEntity();
		while (e instanceof PartEntity<?> pe) e = pe.getParent();
		this.attacker = e instanceof LivingEntity le ? le : null;
	}

	void setupAttackerProfile(@Nullable LivingEntity entity, @Nullable ItemStack stack) {
		if (attacker == null && entity != null) attacker = entity;
		if (weapon.isEmpty() && stack != null) weapon = stack;
	}

	public void onSetNewDamage(float damage) {
		if (logEvent != null && log != null) {
			log.eventLayer(logEvent, damage);
		}
	}

	public void onIncoming(LivingIncomingDamageEvent event, Consumer<LivingIncomingDamageEvent> cons) {
		target = event.getEntity();
		cont = event.getContainer();

		log = AttackLogEntry.of(source, target, getAttacker());

		if (attacker instanceof Player pl) {
			var e = AttackEventHandler.PLAYER.get(pl.getUUID());
			if (e != null) {
				player = e;
				if (!e.getWeapon().isEmpty()) weapon = e.getWeapon();
			}
		}

		var list = AttackEventHandler.getListeners();
		for (var e : list) e.setupProfile(this, this::setupAttackerProfile);
		log.log(AttackLogEntry.Stage.INCOMING, originalDamage);
		boolean cancelled = false;
		for (var e : list) {
			var cancel = e.onAttack(this);
			if (cancel) {
				cancelled = true;
				log.logImmunity(e);
			}
		}
		if (!noCancellation && cancelled) {
			event.setCanceled(true);
			log.end();
			return;
		}
		float damage = offenseModifiers.run(event.getAmount(), log.initModifiers(),
				e -> e.onHurt(this),
				e -> e.onHurtMaximized(this),
				event(event, cons));
		if (noCancellation && event.isCanceled()) event.setCanceled(false);
		event.setAmount(damage);
		log.log(AttackLogEntry.Stage.INCOMING_POST, damage);
		if (event.isCanceled() || damage <= 0) {
			log.end();
		}
	}

	public void onDamage(LivingDamageEvent.Pre event, Consumer<LivingDamageEvent.Pre> cons) {
		if (log == null) {
			target = event.getEntity();
			cont = event.getContainer();
			log = AttackLogEntry.of(source, target, getAttacker());
			log.markLateEntry();
		}
		log.log(AttackLogEntry.Stage.DAMAGE, event.getNewDamage());
		float damage = defenseModifiers.run(event.getNewDamage(), log.initModifiers(),
				e -> e.onDamage(this),
				e -> e.onDamageFinalized(this),
				event(event, cons));
		log.log(AttackLogEntry.Stage.DAMAGE_POST, damage);
		event.setNewDamage(damage);
	}

	private static final ResourceLocation EVENT_OFFENSIVE = L2DamageTracker.loc("event_offensive");
	private static final ResourceLocation EVENT_DEFENSIVE = L2DamageTracker.loc("event_defensive");

	private DamageModifier event(LivingIncomingDamageEvent event, Consumer<LivingIncomingDamageEvent> cons) {
		return new Nonlinear(EVENT_OFFENSIVE, DamageModifier.Order.EVENT, 0, f -> {
			event.setAmount(f);
			logEvent = event;
			ImmunityDataExtra.get(event).attach(log);
			cons.accept(event);
			ImmunityDataExtra.get(event).end();
			logEvent = null;
			return event.getAmount();
		});
	}

	private DamageModifier event(LivingDamageEvent.Pre event, Consumer<LivingDamageEvent.Pre> cons) {
		return new Nonlinear(EVENT_DEFENSIVE, DamageModifier.Order.EVENT, 0, f -> {
			event.setNewDamage(f);
			logEvent = event;
			cons.accept(event);
			logEvent = null;
			return event.getNewDamage();
		});
	}

	public void end() {
		if (log != null) log.end();
	}

}
